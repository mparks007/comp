package main

import (
	"fmt"

	"github.concur.com/mparks/adder/svc"
)

func main() {
	fmt.Println("Adder Server")

	svc.PrintInServer()
}
