package svc

type Relay struct {
	InA bool
	InB bool
	Out bool
}
