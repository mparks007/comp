package svc

import "fmt"

func PrintInServer() {
	fmt.Println("In Server")
}
