package circuit

type andGate struct {
	relay1 *relay
	relay2 *relay
}

func newANDGate(pin1 emitter, pin2 emitter) *andGate {
	g := &andGate{}

	g.relay1 = newRelay(&battery{}, pin1)
	g.relay2 = newRelay(g.relay1.closedOut, pin2)

	return g
}

func (g *andGate) Emitting() bool {
	return g.relay2.emittingClosed()
}

type orGate struct {
	relay1 *relay
	relay2 *relay
}

func newORGate(pin1 emitter, pin2 emitter) *orGate {
	g := &orGate{}

	g.relay1 = newRelay(&battery{}, pin1)
	g.relay2 = newRelay(&battery{}, pin2)

	return g
}

func (g *orGate) Emitting() bool {
	return g.relay1.emittingClosed() || g.relay2.emittingClosed()
}

type nandGate struct {
	relay1 *relay
	relay2 *relay
}

func newNANDGate(pin1 emitter, pin2 emitter) *nandGate {
	g := &nandGate{}

	g.relay1 = newRelay(&battery{}, pin1)
	g.relay2 = newRelay(&battery{}, pin2)

	return g
}

func (g *nandGate) Emitting() bool {
	return g.relay1.emittingOpen() || g.relay2.emittingOpen()
}

type norGate struct {
	relay1 *relay
	relay2 *relay
}

func newNORGate(pin1 emitter, pin2 emitter) *norGate {
	g := &norGate{}

	g.relay1 = newRelay(&battery{}, pin1)
	g.relay2 = newRelay(g.relay1.aIn, pin2)

	return g
}

func (g *norGate) Emitting() bool {
	return g.relay2.emittingOpen()
}
