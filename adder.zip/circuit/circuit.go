package circuit

type emitter interface {
	Emitting() bool
}
