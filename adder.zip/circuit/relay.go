package circuit

type relay struct {
	aIn       emitter
	bIn       emitter
	closedOut *twoSourcePin
}

func newRelay(a emitter, b emitter) *relay {
	r := &relay{}

	r.aIn = a
	r.bIn = b
	r.closedOut = newTwoSourcePin(r.aIn, r.bIn)

	return r
}

func (r *relay) emittingOpen() bool {
	return r.aIn != nil && r.aIn.Emitting() &&
		(r.bIn == nil ||
			(r.bIn != nil && !r.bIn.Emitting()))
}

func (r *relay) emittingClosed() bool {
	return r.aIn != nil && r.aIn.Emitting() &&
		r.bIn != nil && r.bIn.Emitting()
}
