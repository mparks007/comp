package circuit

import "testing"

func TestRelayPower_AInPowerOnly_HasOpenPower(t *testing.T) {
	r := newRelay(&battery{}, nil)

	want := true
	got := r.emittingOpen()
	if got != want {
		t.Error("Expected a relay, with a battery only on AIn, to output power in the open position.")
	}
}

func TestRelayPower_BInPowerOnly_HasNoPower(t *testing.T) {
	r := newRelay(nil, &battery{})

	want := false
	got := r.emittingOpen() || r.emittingClosed()
	if got != want {
		t.Error("Expected a relay, with a battery only on BIn, to output no power.")
	}
}

func TestRelayPower_AInAndBInPower_HasClosedPower(t *testing.T) {
	r := newRelay(&battery{}, &battery{})

	want := true
	got := r.emittingClosed()
	if got != want {
		t.Error("Expected a relay, with a battery on AIn and BIn, to output power in the closed position.")
	}
}

func TestRelayPower_AInAndBInNoPower_HasNoPower(t *testing.T) {
	r := &relay{}

	want := false
	got := r.emittingOpen() || r.emittingClosed()
	if got != want {
		t.Error("Expected a relay, with no input power, to output no power.")
	}
}

/**********************************/
/************** AND ***************/
/**********************************/

func TestANDGatePower_BothInputsUnpowered_NoPower(t *testing.T) {
	g := newANDGate(nil, nil)

	want := false
	got := g.Emitting()
	if got != want {
		t.Error("Expected an AND gate, with no powered inputs, to output no power (off).")
	}
}

func TestANDGatePower_OnlyFirstInputPowered_NoPower(t *testing.T) {
	g := newANDGate(&battery{}, nil)

	want := false
	got := g.Emitting()
	if got != want {
		t.Error("Expected an AND gate, with only its first input pin powered, to outuput no power (off).")
	}
}

func TestANDGatePower_OnlySecondInputPowered_NoPower(t *testing.T) {
	g := newANDGate(nil, &battery{})

	want := false
	got := g.Emitting()
	if got != want {
		t.Error("Expected an AND gate, with only its second input pin powered, to output no power (off).")
	}
}

func TestANDGatePower_BothInputsPowered_HasPower(t *testing.T) {
	g := newANDGate(&battery{}, &battery{})

	want := true
	got := g.Emitting()
	if got != want {
		t.Error("Expected an AND gate, with both its input pins powered, to output power (on).")
	}
}

/**********************************/
/*************  OR  ***************/
/**********************************/

func TestORGatePower_BothInputsUnpowered_NoPower(t *testing.T) {
	g := newORGate(nil, nil)

	want := false
	got := g.Emitting()
	if got != want {
		t.Error("Expected an OR gate, with no powered inputs, to output no power (off).")
	}
}

func TestORGatePower_OnlyFirstInputPowered_HasPower(t *testing.T) {
	g := newORGate(&battery{}, nil)

	want := true
	got := g.Emitting()
	if got != want {
		t.Error("Expected an OR gate, with only its first input pin powered, to output power (on).")
	}
}

func TestORGatePower_OnlySecondInputPowered_HasPower(t *testing.T) {
	g := newORGate(nil, &battery{})

	want := true
	got := g.Emitting()
	if got != want {
		t.Error("Expected an OR gate, with only its second input pin powered, to output power (on).")
	}
}

func TestORGatePower_BothInputsPowered_HasPower(t *testing.T) {
	g := newORGate(&battery{}, &battery{})

	want := true
	got := g.Emitting()
	if got != want {
		t.Error("Expected an OR gate, with both its input pins powered, to output power (on).")
	}
}

/**********************************/
/************* NAND ***************/
/**********************************/

func TestNANDGatePower_BothInputsUnpowered_HasPower(t *testing.T) {
	g := newNANDGate(nil, nil)

	want := true
	got := g.Emitting()
	if got != want {
		t.Error("Expected a NAND gate, with no powered inputs, to output power (on).")
	}
}

func TestNANDGatePower_OnlyFirstInputPowered_HasPower(t *testing.T) {
	g := newNANDGate(&battery{}, nil)

	want := true
	got := g.Emitting()
	if got != want {
		t.Error("Expected a NAND gate, with only its first input pin powered, to outuput power (on).")
	}
}

func TestNANDGatePower_OnlySecondInputPowered_HasPower(t *testing.T) {
	g := newNANDGate(nil, &battery{})

	want := true
	got := g.Emitting()
	if got != want {
		t.Error("Expected a NAND gate, with only its second input pin powered, to output power (on).")
	}
}

func TestNANDGatePower_BothInputsPowered_NoPower(t *testing.T) {
	g := newNANDGate(&battery{}, &battery{})

	want := false
	got := g.Emitting()
	if got != want {
		t.Error("Expected a NAND gate, with both its input pins powered, to output no power (off).")
	}
}

/**********************************/
/************** NOR ***************/
/**********************************/

func TestNORGatePower_BothInputsUnpowered_HasPower(t *testing.T) {
	g := newNORGate(nil, nil)

	want := true
	got := g.Emitting()
	if got != want {
		t.Error("Expected a NOR gate, with no powered inputs, to output power (on).")
	}
}

func TestNORGatePower_OnlyFirstInputPowered_NoPower(t *testing.T) {
	g := newNORGate(&battery{}, nil)

	want := false
	got := g.Emitting()
	if got != want {
		t.Error("Expected a NOR gate, with only its first input pin powered, to outuput no power (off).")
	}
}

func TestNORGatePower_OnlySecondInputPowered_NoPower(t *testing.T) {
	g := newNORGate(nil, &battery{})

	want := false
	got := g.Emitting()
	if got != want {
		t.Error("Expected a NOR gate, with only its second input pin powered, to output no power (off).")
	}
}

func TestNORGatePower_BothInputsPowered_NoPower(t *testing.T) {
	g := newNORGate(&battery{}, &battery{})

	want := false
	got := g.Emitting()
	if got != want {
		t.Error("Expected a NOR gate, with both its input pins powered, to output no power (off).")
	}
}
