package circuit

type twoSourcePin struct {
	pwrSourceA emitter
	pwrSourceB emitter
}

func newTwoSourcePin(a emitter, b emitter) *twoSourcePin {
	p := &twoSourcePin{a, b}
	return p
}

func (in *twoSourcePin) Emitting() bool {
	return in.pwrSourceA != nil && in.pwrSourceA.Emitting() &&
		in.pwrSourceB != nil && in.pwrSourceB.Emitting()
}
